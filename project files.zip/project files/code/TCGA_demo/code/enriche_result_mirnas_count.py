'''
Created on 2019-4-9

@author: Liu
'''
import pandas as pd
import os
import sys
from collections import Counter
now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

TAM2_dir =data_dir+"TAM2.0/"
MIEAA_dir =data_dir+"miEAA/"
survival_dir = result_dir+"survival/"
TAM2_files_dir = []
miEAA_files_dir = []
survival_files_dir = []

for files in os.listdir(MIEAA_dir):
    if os.path.splitext(files)[1]==".csv":
    	if 'TCGA-' in files:
        	miEAA_files_dir.append(files)

for file in miEAA_files_dir:
	MiRNAsList  = list(pd.read_csv(MIEAA_dir+file)["miRNAs/precursors"])
	miRNAs=[]
	for mirnaStr in MiRNAsList:
		miRNAs.extend(mirnaStr.split(';'))
	result = Counter(miRNAs)
	df = pd.DataFrame(result,index = [file.split(".")[0]])
	df.to_csv(MIEAA_dir+"miRNA_count/"+file)

print("ok")

