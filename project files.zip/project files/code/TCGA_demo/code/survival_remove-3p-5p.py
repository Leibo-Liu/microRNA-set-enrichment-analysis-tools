'''
Created on 2019-4-9

@author: Liu
'''
import pandas as pd
import os
import sys


now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

survival_dir = result_dir+"survival/pval.csv"
survival_data = pd.read_csv(survival_dir,index_col = 0)
survival_data_columns  = survival_data.columns.values.tolist()
print("survival_data_columns:"+str(len(survival_data_columns)))

miRNAList=[]
for mirnaStr in survival_data_columns:
	miRNA = mirnaStr.replace("-3p","")
	miRNA = miRNA.replace("-5p","") 
	miRNAList.append(miRNA)
miRNAList = list(set(miRNAList))
print("miRNAList:"+str(len(miRNAList)))

inter_list = list(set(miRNAList).intersection(set(survival_data_columns)))
outer_list = [x for x in miRNAList if x not in inter_list]
disease_names = list(pd.read_table(data_dir+"20cancers_name.txt",sep=",",header=None)[0])
print("disease_names:"+str(len(disease_names)))

data = survival_data.loc[disease_names,inter_list]
for disease in disease_names:
	for mirna in outer_list:
		mirna3p = mirna+"-3p"
		mirna5p = mirna+"-5p"
		if mirna3p in survival_data_columns and mirna5p in survival_data_columns:
			data.loc[disease,mirna] = min(survival_data.loc[disease,[mirna3p,mirna5p]])
		elif mirna3p in survival_data_columns:
			 data.loc[disease,mirna] = survival_data.loc[disease,mirna3p]
		elif mirna5p in survival_data_columns:
			 data.loc[disease,mirna] = survival_data.loc[disease,mirna5p]
		else:
			print(mirna)

print(data)
data.to_csv(result_dir+"survival/pval-20-3p-5p.csv")
