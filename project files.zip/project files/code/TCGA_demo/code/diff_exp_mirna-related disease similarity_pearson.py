'''
Created on 2019-4-8

@author: Liu
'''
import os
import pandas as pd
from scipy.stats.mstats_basic import pearsonr
import sys


now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

files_name =[]
now_dir =result_dir+"edgeR_result/all/"
for files in os.listdir(now_dir):
    if os.path.splitext(files)[1]==".csv":
        files_name.append(files)
disease_pearson_diff = pd.DataFrame()
for file1 in files_name:
    data1 = pd.read_csv(now_dir+file1,index_col=0)["logFC"]
    for file2 in files_name: 
        data2 = pd.read_csv(now_dir+file2,index_col=0)["logFC"]
        disease_pearson_diff.loc[file1.split(".")[0],file2.split(".")[0]] = pearsonr(data1,data2)[0]
print(disease_pearson_diff)
save_dir = result_dir+"pearson_result/"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)
disease_pearson_diff.to_csv(save_dir+"disease_pearson_diff.csv")