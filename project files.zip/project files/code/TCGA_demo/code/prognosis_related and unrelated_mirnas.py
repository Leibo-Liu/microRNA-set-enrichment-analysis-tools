'''
Created on 2019-4-9

@author: Liu
'''
import pandas as pd
import sys

now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

survival_pval= pd.read_csv(result_dir+"survival/pval-20-3p-5p.csv",index_col = 0)
disease_list =survival_pval.index.tolist()
TAM2_mirna_counts_file_dir= data_dir+"TAM2.0/miRNA_count/p-value(0.05)/"
pf = []
puf = []
survival_relected_mirnas_count = pd.DataFrame(columns=["Count"])
survival_unrelected_mirnas_count = pd.DataFrame(columns=["Count"])

for dis in disease_list:
    TAM2_data=pd.read_csv(TAM2_mirna_counts_file_dir+dis+".csv",index_col = 0)
    TAM2_mirnas = TAM2_data.columns.values.tolist()
    
    pf_mirnas = list(set(TAM2_mirnas).intersection(set(survival_pval.loc[dis,survival_pval.loc[dis]<0.05].index.tolist())))
    puf_mirnas = list(set(TAM2_mirnas).intersection(set(survival_pval.loc[dis,survival_pval.loc[dis]>0.05].index.tolist())))
    
    relected_df = TAM2_data.loc[dis,pf_mirnas]
    unrelected_df = TAM2_data.loc[dis,puf_mirnas]
    
    for mirna in relected_df.index.tolist():
        if mirna not in survival_relected_mirnas_count.index.tolist():
            survival_relected_mirnas_count.loc[mirna,"Count"]=relected_df[mirna]
        else:
            survival_relected_mirnas_count.loc[mirna,"Count"] += relected_df[mirna]
    for mirna in unrelected_df.index.tolist():
        if mirna not in survival_unrelected_mirnas_count.index.tolist():
            survival_unrelected_mirnas_count.loc[mirna,"Count"]=unrelected_df[mirna]
        else:
            survival_unrelected_mirnas_count.loc[mirna,"Count"] += unrelected_df[mirna]
    

survival_relected_mirnas_count.to_csv(result_dir+"survival/survival_related_mirnas_count.csv")
survival_unrelected_mirnas_count.to_csv(result_dir+"survival/survival_unrelated_mirnas_count.csv")
 

print("ok")
        
            

