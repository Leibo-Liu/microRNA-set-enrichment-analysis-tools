# -*- coding:utf-8 -*-
'''
Created on 2019年9月24日

@author: dell
'''
import pandas as pd
import numpy as np
import misim
import sys



def getDSN(names):
    ''' Accept a training set and return a disease similarity network
    '''
    print("generating disease similarity network...")
    mtree = misim.loadMtree(MTREEFILE)
#     print(mtree)
#     names = sorted(trainset['disease'].unique().tolist())
    print("total %d diseases..." % len(names))
    dsn = pd.DataFrame(index=names, columns=names)
    for x in names:
#         print(x)
        for y in names:
            if x == y:
                dsn.loc[x, y] = 1.0
            elif pd.isnull(dsn.loc[y, x]):
                dagx = misim.genDAG(mtree[x])
                dagy = misim.genDAG(mtree[y])

                
                dsn.loc[x, y] = misim.semSim(dagx, dagy, 0.5)
            else:
                dsn.loc[x, y] = dsn.loc[y, x]
#     return dsn.index.values, dsn.values
    print(dsn)
    dsn.to_csv(result_dir+"spearman_result/dsn.csv")

now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")
MTREEFILE = data_dir+"DSN/mtrees2019.bin"

MeSH_data = pd.read_excel(data_dir+"DSN/MeSH-TCGA.xlsx")["MeSH"]
names = sorted(MeSH_data.tolist())
print(names)
getDSN(names)
