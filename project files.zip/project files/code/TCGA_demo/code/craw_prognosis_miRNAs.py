#coding:utf-8
'''
Created on 2019年3月25日

@author: Liu
'''
import urllib.request
from urllib import parse
from bs4 import BeautifulSoup
import pandas as pd
import os
import sys

def fun(mirna):
    p_val = []
    HR = []
    url="http://starbase.sysu.edu.cn/ajaxphp/datatables/survExpTableResult.php"
#     header = {"User_Agent" :"'Mozilla/5.0"}
    data1={}
    data1['gene']=mirna
    data1["source"] = "miRNA"
    data = parse.urlencode(data1).encode("utf-8")
    #request = urllib.request.Request(url,headers=header)
    response = urllib.request.urlopen(url,data=data)
    cont = response.read()
    s = str(cont,"utf-8").replace(r"\n", "").replace(r"\/", r"/")
    cont = bytes(s,encoding="utf-8")
    soup = BeautifulSoup(cont,"html.parser",from_encoding="utf-8")
    trs = soup.find_all("tr")
    for tr in trs:
        tds = tr.find_all("td")
        if tds[0].get_text() not in cancer_name:
            cancer_name.append(tds[0].get_text())
        p_val.append(float(tds[6].get_text()))
        HR.append(float(tds[5].get_text()))
    return p_val,HR

if __name__ == '__main__':
    now_dir = sys.path[0].replace("\\","/")+"/"
    data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
    result_dir = now_dir.replace("code/TCGA_demo/code/","result/")
    
    file__dirs =[]

    miRNA_set =  pd.read_csv(data_dir+"miRNAs.csv")["miRNA"]
    
    cancer_name = []
    data_p={}
    data_HR={}
    a = len(miRNA_set)
    for mirna in miRNA_set:
        p_val,HR = fun(mirna)
        p_val_3p,HR_3p = fun(mirna+"-3p")
        p_val_5p,HR_5p = fun(mirna+"-5p")
       
        if sum(p_val)!=0 and sum(HR)!=0:
            data_p[mirna]= p_val
            data_HR[mirna]= HR
        if sum(p_val_3p)!=0 and sum(HR_3p)!=0:
            data_p[mirna+"-3p"]= p_val_3p
            data_HR[mirna+"-3p"]= HR_3p
        if sum(p_val_5p)!=0 and sum(HR_5p)!=0 :
            data_p[mirna+"-5p"]= p_val_5p
            data_HR[mirna+"-5p"]= HR_5p
        print(a)
        a = a-1
    result_pvalue = pd.DataFrame(data_p,index= cancer_name)
    result_HR = pd.DataFrame(data_HR,index= cancer_name)
    
    save_dir = result_dir+"survival/"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
       
    result_pvalue.to_csv(save_dir+"pval.csv")
    result_HR.to_csv(save_dir+"HR.csv")
    print("ok")