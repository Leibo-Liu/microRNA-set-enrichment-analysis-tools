'''
Created on 2019-4-3

@author: Liu
'''
import pandas as pd
import os
import sys


now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

diff_dir =result_dir+"edgeR_result/"
survival_dir = result_dir+"survival/"
diff_files_dir = []
survival_files_dir = []

for files in os.listdir(diff_dir):
    if os.path.splitext(files)[1]==".csv":
        diff_files_dir.append(files)

P_survival = pd.read_csv(survival_dir+"pval.csv",index_col=0,header=0)
HR_survival = pd.read_csv(survival_dir+"HR.csv",index_col=0,header=0)
disease_list = P_survival.index
mirna_list = P_survival.columns
for diff_file in diff_files_dir:
    print(diff_file)
    
    for disease in disease_list:
        if disease in diff_file:
            diff_data = pd.read_csv(diff_dir+diff_file,index_col=0).drop_duplicates()
            print(len(diff_data))
#             survival_data = pd.read_csv(survival_dir+survival_file,header=0,index_col=0).drop_duplicates()
            if len(diff_data)>0:
                save_data = pd.DataFrame()
                diff_mirna = diff_data.index.tolist()
                sur_mirna = mirna_list
                mirnas = list(set(sur_mirna))
                mirna_ = list(set([mir.replace("-3p","").replace("-5p","") for mir in mirnas]))
                diff_mirnas = [mirna for mirna in diff_mirna if mirna not in mirna_]
                save_data = diff_data.loc[diff_mirnas]
                save_data.columns =["logFC","logCPM","F","diff_P"]
                save_data.loc[diff_mirnas,"survival_P"] = 1
                save_data.loc[diff_mirnas,"HR"] = 1
                mirnas_ =[]
                mirna_3p =[mirna+"-3p" for mirna in diff_mirna]
                mirna_5p =[mirna+"-5p" for mirna in diff_mirna]
                mirnas_.extend(diff_mirna)
                mirnas_.extend(mirna_3p)
                mirnas_.extend(mirna_5p)
                mirnas_ = list(set(mirnas_).intersection(set(mirnas)))
                
                for mirna in mirnas_:
                    save_data.loc[mirna,"logFC"] = diff_data.loc[mirna.replace("-3p","").replace("-5p",""),'logFC']
                    save_data.loc[mirna,"logCPM"] = diff_data.loc[mirna.replace("-3p","").replace("-5p",""),'logCPM']
                    save_data.loc[mirna,"F"] = diff_data.loc[mirna.replace("-3p","").replace("-5p",""),'F']
                    save_data.loc[mirna,"diff_P"] = diff_data.loc[mirna.replace("-3p","").replace("-5p",""),'PValue']
                    save_data.loc[mirna,"survival_P"] = P_survival.loc[diff_file.split("-")[1].split(".")[0],mirna]
                    save_data.loc[mirna,"HR"] = HR_survival.loc[diff_file.split("-")[1].split(".")[0],mirna]
               
                save_dir =(survival_dir+diff_file)
                save_data.to_csv(save_dir)
            else:
                continue
        else:
            continue
    
            
    