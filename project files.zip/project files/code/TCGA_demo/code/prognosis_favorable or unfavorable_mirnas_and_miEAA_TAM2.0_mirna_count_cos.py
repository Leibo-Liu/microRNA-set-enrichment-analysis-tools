'''
Created on 2019-5-7
@author: Liu
'''
import pandas as pd
import sys
import os
import math
from scipy.stats.mstats_basic import pearsonr

now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

survival_pval= pd.read_csv(result_dir+"survival/pval-20-3p-5p.csv",index_col = 0)
survival_hr= pd.read_csv(result_dir+"survival/HR.csv",index_col = 0)
disease_list =survival_pval.index.tolist()

enrich_file_dir = [data_dir+"miEAA/miRNA_count/p-value(0.05)/",data_dir+"TAM2.0/miRNA_count/p-value(0.05)/"]
for file_dir in enrich_file_dir:
    print("======================")
    save_str=""
    for disease in disease_list:
        if os.path.exists(file_dir+disease+".csv"):
            data = pd.read_csv(file_dir+disease+".csv",index_col=0)
            data_mirna_list = data.columns.values.tolist()
            survival_mirna_list = survival_pval.loc[disease,survival_pval.loc[disease]<0.05].index.tolist()
            TCGA_disease = disease.split("-")[1]
            survival_hr_0 = survival_hr.loc[TCGA_disease,survival_hr.loc[TCGA_disease]<1.0].index.tolist()
            survival_hr_1 = survival_hr.loc[TCGA_disease,survival_hr.loc[TCGA_disease]>1.0].index.tolist()
            
            mirna_list = list(set(data_mirna_list).intersection(set(survival_mirna_list)))
            mirna_list = list(set(mirna_list).intersection(set(survival_hr_1)))
#             mirna_list = list(set(survival_hr_1).intersection(set(survival_mirna_list)))
            
            if len(mirna_list)!=0:
                xx = sum([x*x for x in survival_pval.loc[disease,survival_mirna_list] ])
                yy = sum([y*y for y in data.loc[disease,data_mirna_list] ])
                xy = sum([x*y for x,y in zip(survival_pval.loc[disease,mirna_list],data.loc[disease,mirna_list])])
                if xx!=0 and yy!=0:
                    score = xy/math.sqrt(xx*yy)
                else:
                    score = 0.0
            else:
                score = 0.0
        else:
            score = 0.0
        save_str += disease+"\t"+str(score)+"\n"
    print(save_str)
    save_file = open(file_dir+"survival_cosSimilarity(p-value(0.05)HR(1).txt","w")
    save_file.write(save_str)
    save_file.close()   

print("ok")
        
            

