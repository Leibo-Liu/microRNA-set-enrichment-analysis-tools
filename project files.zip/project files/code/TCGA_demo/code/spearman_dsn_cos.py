'''
Created on 2019-5-7
@author: Liu
'''
import pandas as pd
import sys
import math

now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

disease_similarity_MISIM= pd.read_csv(result_dir+"spearman_result/dsn.csv",index_col = 0)
disease_list =list(set(disease_similarity_MISIM.index.tolist()))

file_list = ["miEAA_disease_spearman","TAM1.0_disease_spearman","TAM2.0_disease_spearman"]

for name in file_list:
    file_data = pd.read_csv(result_dir+"spearman_result/"+name+".csv",index_col = 0)
    file_data_disease_list = list(set(file_data.index.tolist()))

    sava_file = open(result_dir+"3c/"+name+"_dsn_cos.txt","w")
    for disease in disease_list:
        if disease not in file_data_disease_list:
            score= 0
        else:
            inter_disease_list = list(set(disease_list).intersection(set(file_data_disease_list)))

            xx = sum([x*x for x in disease_similarity_MISIM.loc[disease,inter_disease_list] ])
            yy = sum([y*y for y in file_data.loc[disease,inter_disease_list] ])
            xy = sum([x*y for x,y in zip(disease_similarity_MISIM.loc[disease,inter_disease_list],file_data.loc[disease,inter_disease_list])])
            score = xy/math.sqrt(xx*yy)
           
        sava_str = disease +"\t"+ str(score)+"\n"
        sava_file.write(sava_str)
    sava_file.close()
    
print("ok")
        
            

