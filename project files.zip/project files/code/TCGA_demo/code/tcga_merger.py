'''
Created on 2019-4-9

@author: Liu
'''
import pandas as pd		#this is the standard
import os
import sys

now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

data = pd.read_csv(data_dir+"sample_sheet.csv",header=0)
data.columns = ['File_ID','File_Name','Project_ID','Sample_ID']	
project_id = data["Project_ID"].unique()

length = len(project_id)
if not os.path.exists(result_dir+"merger_data"):
	os.makedirs(result_dir+"merger_data")
miRNA_ID = pd.read_csv(data_dir+"mirnaList.csv",header=None)
n=0
for i in range(0,len(project_id)):
	all_data=pd.DataFrame()
	dis_result = pd.DataFrame()
	not_dis_result = pd.DataFrame()
	disease_data = data[data.Project_ID == project_id[i]]
	for index in disease_data.index:
		count_data = pd.read_csv(data_dir+"TCGA_source_data/"+data.iloc[index].File_ID+"/"+data.iloc[index].File_Name,header=0,sep="\t")
		if data.iloc[index].Sample_ID[-3:]=='01A':
			dis_result[data.iloc[index].Sample_ID] = count_data['read_count']
		elif data.iloc[index].Sample_ID[-3:]=='11A':
			not_dis_result[data.iloc[index].Sample_ID] = count_data['read_count']
	if dis_result.size != 0 and not_dis_result.size!=0:
		res = not_dis_result
		ysamples = [columns[:-4] for columns in not_dis_result] 
		xsamples = [columns[:-4] for columns in dis_result]
		samples = list(set(ysamples).intersection(set(xsamples)))
		if len(samples)!= 0:
			for z in samples:
				all_data[z+"-01A"] = dis_result[z+"-01A"]
			for z in samples:
				all_data[z+"-11A"] = not_dis_result[z+"-11A"]
			all_data.insert(0,"Tags",miRNA_ID[0])
			all_data.to_csv(result_dir+"merger_data/"+project_id[i]+".csv",sep=",",header=True,index=False)	
			n=n+1
			print("鎴愬姛瀛樺偍"+str(n)+"涓枃浠�")
	print("宸插畬鎴愶細"+str(i+1)+"/"+str(length)+"\n")
print("璁＄畻缁撴潫锛岀粨鏋滀繚瀛樺湪"+result_dir+"merger_data 涓�")
