'''
Created on 2019-4-9

@author: Liu
'''
import os
import pandas as pd
from scipy.stats import spearmanr
import math
import sys
import numpy


now_dir = sys.path[0].replace("\\","/")+"/"
data_dir=now_dir.replace("code/TCGA_demo/code/","data/")
result_dir = now_dir.replace("code/TCGA_demo/code/","result/")

files_name =[]
for tool_name in ["miEAA","TAM1.0","TAM2.0"]:
    now_dir =data_dir+tool_name+"/"
    for files in os.listdir(now_dir):
        if os.path.splitext(files)[1]==".csv":
            files_name.append(files)
    disease_pearson = pd.DataFrame()
    if tool_name == "miEAA":
        p_val = "p-value"
    else:
        p_val = "P-value"
    
    for file1 in files_name:
        for file2 in files_name: 
            if file1==file2:
                disease_pearson.loc[file1.split(".")[0],file2.split(".")[0]] = 1
            else:
                data1 = pd.read_csv(now_dir+file1,index_col=1)[[p_val]]
                data2 = pd.read_csv(now_dir+file2,index_col=1)[[p_val]]
                
                data1_disease = data1.index.tolist()
                data2_disease = data2.index.tolist()
                disease_list = data1_disease
                disease_list.extend(data2_disease)
                disease_list = list(set(disease_list))
               
                matr = numpy.ones([len(disease_list),2])
                calculate = pd.DataFrame(matr)
                calculate.index=disease_list
                calculate.columns=['data1_p','data2_p']
                
                calculate.loc[data1.index.tolist(),"data1_p"]= data1.loc[data1.index.tolist(),p_val]
                calculate.loc[data2.index.tolist(),"data2_p"]= data2.loc[data2.index.tolist(),p_val]
                
                for dis in calculate.index.tolist():
                    if calculate.loc[dis,"data1_p"] >0:
                        calculate.loc[dis,"data1_p"] = 0-math.log(calculate.loc[dis,"data1_p"] )
                    if calculate.loc[dis,"data2_p"] >0:
                        calculate.loc[dis,"data2_p"] = 0-math.log(calculate.loc[dis,"data2_p"] )
                disease_pearson.loc[file1.split(".")[0],file2.split(".")[0]] = spearmanr( calculate["data1_p"],calculate["data2_p"])[0]
    print(tool_name+" calculate OK...")
    disease_pearson.to_csv(result_dir+"spearman_result/"+tool_name+"_disease_spearman.csv") 